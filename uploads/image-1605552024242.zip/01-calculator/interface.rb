require_relative 'calculator'

# Create a dummy user value to make sure we get into the loop
answer = "y"

# Enter the loop until user wants to quit
# while answer.downcase != 'n'
# while answer.downcase == 'y'
# until answer.downcase != 'y'
until answer.downcase == 'n'
  # Ask for a number
  puts "Enter a first number"
  # Get the user answer
  first_number = gets.chomp.to_i
  # Ask for a second number
  puts "Enter a second number"
  # Get the user answer
  second_number = gets.chomp.to_i
  # Ask for an operator
  puts "Choose operation (+ - * /)"
  # Get the user answer
  operator = gets.chomp
  # Calculate the operation between the first and
  # second numbers, given the desired operation
  puts calculate(first_number, second_number, operator)
  # Ask if user wants to continue
  puts "Do you want to calculate again? [Y/N]"
  # Get the user answer
  answer = gets.chomp
# End the loop
end

puts "Goodbye!"
