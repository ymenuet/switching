def calculate(x, y, operator)
  # RETURN the correct result given x, y and the operator
  # NO PUTS
  if operator == "+"
    return x + y
  elsif operator == "-"
    return x - y
  elsif operator == "*"
    return x * y
  elsif operator == "/"
    return x.fdiv(y)
  else
    return "invalid operator"
  end
end
